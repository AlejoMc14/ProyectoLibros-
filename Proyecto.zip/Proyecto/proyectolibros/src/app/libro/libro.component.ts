import { Component } from '@angular/core';
import { Libros } from './libros';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-libro',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './libro.component.html',
  styleUrl: './libro.component.css'
})
export class LibroComponent {

  libro : Libros[] = [

    new Libros('Cien años de soledad', '417', '1967','Gabriel Garcia Marquez', 'Novela'),
    new ()
  ];
}
