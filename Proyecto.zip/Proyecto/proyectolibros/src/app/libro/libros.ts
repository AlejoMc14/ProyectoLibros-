import { Data } from "@angular/router";

export class Libros {
 
    tituloLibro: string;
    paginas: Int16Array;
    fechaPubli: Data;
    autor1: string;
    genero: string;

}
